# Google Cloud Speech API examples

This directory contains samples using the [Google Cloud Speech
API](https://cloud.google.com/speech/).
