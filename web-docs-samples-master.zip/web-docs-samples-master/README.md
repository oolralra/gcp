# Google Cloud Platform web samples

This repo contains web application samples for [Google Cloud
Platform](https://cloud.google.com/).

[![Build
Status](https://travis-ci.org/GoogleCloudPlatform/web-docs-samples.svg?branch=master)](https://travis-ci.org/GoogleCloudPlatform/web-docs-samples)
[![Coverage Status](https://coveralls.io/repos/github/GoogleCloudPlatform/web-docs-samples/badge.svg?branch=HEAD)](https://coveralls.io/github/GoogleCloudPlatform/web-docs-samples?branch=HEAD)
[![js-semistandard-style](https://img.shields.io/badge/code%20style-semistandard-brightgreen.svg?style=flat-square)](https://github.com/Flet/semistandard)

For more detailed introduction to a product, check the README.md in the
corresponding folder.

## Contributing changes

* See [CONTRIBUTING.md](CONTRIBUTING.md)

## Licensing

* See [LICENSE](LICENSE)
